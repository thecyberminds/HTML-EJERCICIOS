<?php


//guardamos los datos de las cajas de texto

$nombre=$_POST['nombre'];
$apellidos=$_POST['apellidos'];
$direccion=$_POST['direccion'];
$poblacion=$_POST['poblacion'];
$codigopostal=$_POST['codigopostal'];
$email=$_POST['email'];
$telefono=$_POST['telefono'];


//construimos mensaje
$destinatario="lauracuriel555@digitechfp@gmail.com";
$asusnto="formulario web contacto";
$informacion="nombre:" .$nombre."\n";
$informacion="apellidos" .$apellidos. "\n";
$informacion="Direccion" .$direccion. "\n";
$informacion="poblacion" .$poblacion. "\n";
$informacion="codigo postal" .$codigopostal. "\n";
$informacion="email" .$email. "\n";
$informacion="telefono" .$telefono. "\n";

//llamamos a la funcion mail()

mail($destinatario,$asusnto,utf8_decode ($informacion),"from: " .$email);

echo "bien hecho"









?>